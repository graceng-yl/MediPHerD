<?php include('header.php'); ?>

<?php

$plants_query = "SELECT * FROM plants WHERE plant_id = 'P001'";
$materials_query = "SELECT * FROM materials WHERE materials.mat_id IN (SELECT materials_relation.mat_id FROM materials_relation WHERE materials_relation.plant_id = 'P001')";
$keywords_query = "SELECT * FROM keywords WHERE keywords.keyw_id IN (SELECT keywords_relation.keyw_id FROM keywords_relation WHERE keywords_relation.plant_id = 'P001')";

$plants_result = mysqli_query($conn, $plants_query) or die(mysqli_error($conn));
$materials_result = mysqli_query($conn, $materials_query) or die(mysqli_error($conn));
$keywords_result = mysqli_query($conn, $keywords_query) or die(mysqli_error($conn));

?>

<?php while ($plant = mysqli_fetch_assoc($plants_result)) { ?>
<div class="container py-5" id="ep">
	<div class="page_top">
	<table>
		<h1 class="page_title" id="ep_titl"><?= $plant["plant_name"] ?><h1>
		<h2 class="page_desc" id="eptd"><?= $plant["plant_othernames"] ?></h2>

		<br />
		<div class="container mx-5" id="cat_gap">
			<table>
				<tr>
					<th>
						<img src="www/Tongkat_Ali.jpg" class="img-fluid img-center"/>
					</th>
					<th>
					<div>
						<table>
							<tr>
								<th scope="col">Scientific Name: </th>
								<td><em><?= $plant["plant_genus"] ?> <?= $plant["plant_species"] ?></em></td>
							</tr>
							<tr>
								<th scope="col">Plant Family: </th>
								<td><em><?= $plant["plant_family"] ?></em></td>
							</tr>
							<tr>
								<th scope="col">Material: </th>
								<td>
									<?php while ($material = mysqli_fetch_assoc($materials_result)) { ?>
										<?= $material["mat_desc"] ?>
									<?php } ?>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<?php
									$keywords = array();
									while ($keyword = mysqli_fetch_assoc($keywords_result)) {
										$keywords[] = $keyword["keyw_desc"];
									}
									?>
									<?= join(", ", $keywords) ?>
								</td>
							</tr>
						</table>
					</div>
					</th>
				<tr>
			</table>
		</div>

		<div id="ep">
			<h2 class="subsection_title">Usage</h2>
			<div id= "cat_d"><p><?= $plant["plant_usage"] ?></p></div>

			<h2 class="subsection_title">Chemical Constituent</h2>
			<div id= "cat_d"><p><?= $plant["plant_chemconst"] ?></p></div>

			<h2 class="subsection_title">References</h2>
			<div id= "cat_d"><p><?= $plant["plant_refs"] ?></p></div>
		</div>
		
		<div class="container mt-5">
			<h3 class="subsection_title">You might want to know</h3>
			 <div class="row">
				<div class="col-sm-4">
					<h3>Column 1</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
					<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
				</div>
				<div class="col-sm-4">
					<h3>Column 2</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
					<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
				</div>
				<div class="col-sm-4">
					<h3>Column 3</h3>        
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
					<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
				</div>
			 </div>
		</div>		
		
	</table>
	</div>
</div>   
<?php } ?>

<?php include('footer.php'); ?>