        <footer class="text-center py-4 footer">
            <div class="footer_text">
                <b>Copyright &copy; 2022 MediPHerD. All Rights Reserved.</b>
                <p>Developed by Grace Ng Yee Lin, Pendy Tok, Phuah Way Lynn, and Yap Wan Yi</p>
                <p>TWT2231 Web Techniques and Applications - Project</p>
                <i>-- For education purpose only --</i>
            </div>
        </footer>
        </body>

        </html>