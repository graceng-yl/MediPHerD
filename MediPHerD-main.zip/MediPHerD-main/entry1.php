<?php
include('header.php');
?>

<head>
	<title>Entry page</title>
</head>

<body>
	<center>
	<div class="container">
	<form action="" method="POST">
		<input type
		<h1>
			
		</h1>
		<img src = "https://googledrive.com/host/image/<filename>" width="200" height="200">
	</form>
	</div>
	</center>
</body>

<?php
include('footer.php');
?>